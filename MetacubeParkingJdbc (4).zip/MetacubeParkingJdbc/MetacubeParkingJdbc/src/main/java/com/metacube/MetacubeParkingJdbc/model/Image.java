package com.metacube.MetacubeParkingJdbc.model;

import javax.validation.constraints.NotBlank;

import org.springframework.web.multipart.MultipartFile;

/**
 * pojo class for image
 * @author Khushi
 *
 */
public class Image {

	
	
	private MultipartFile image;
	
	private String email;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public MultipartFile getImage() {
		return image;
	}

	public void setImage(MultipartFile image) {
		this.image = image;
	}
	

	
}
