package com.metacube.MetacubeParking.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.metacube.MetacubeParking.model.Employee;
import com.metacube.MetacubeParking.model.LoginEmployee;
import com.metacube.MetacubeParking.model.Pass;
import com.metacube.MetacubeParking.model.Vehicle;

@Controller
public class ParkingController {

	static List<Employee> employeeList = new ArrayList<Employee>();
	List<Employee> employee1 = new ArrayList<Employee>();
	List<Employee> friendList = new ArrayList<Employee>();
	Integer passPrices[];
	
	@GetMapping("/signUp") 
	public String signUp(Model model) {
		model.addAttribute("employee", new Employee());
		return "signUp";
	}
	
	/**
	 * to check validations
	 * @param student
	 * @param result
	 * @return
	 */
	@PostMapping("/signUp") 
	public String doSignUp(@Validated Employee employee, BindingResult result, RedirectAttributes attribute, Model model) {
		if (result.hasErrors()) {
			return "signUp";
			
		} else {
			employeeList.add(employee);
			//attribute.addFlashAttribute("msg", "Employee name : " + employee.getFullName());
			return "redirect:/vehicleForm";	
		}
	}
	
	@GetMapping("/vehicleForm") 
	public String addVehicle(Model model) {
		model.addAttribute("vehicle", new Vehicle());
		return "vehicleForm";
	}
	
	@PostMapping("/registerVehicle")
	public String registerVehicle(@Validated Vehicle vehicle, BindingResult result, RedirectAttributes attribute) {
		if(result.hasErrors()) {
			return "vehicleForm";
		} else {
			attribute.addAttribute("type", vehicle.getVehicleType());
			return "redirect:/getPass";
		}
	}
	
	@GetMapping("/getPass")
	public String getPass(@RequestParam("type") String type, Model model) {
		if ("Cycle".equals(type)) {
			passPrices = new Integer[]{5, 100, 500};
		} else if ("Bike".equals(type)) {
			passPrices = new Integer[]{10, 200, 1000};
		} else if ("Four_Wheeler".equals(type)) {
			passPrices = new Integer[]{20, 500, 3500};
		}
		Map<Integer, String> passMap = new HashMap<Integer, String>();
		passMap.put(passPrices[0], passPrices[0] + "Daily");
		passMap.put(passPrices[1], passPrices[1] + "Monthly");
		passMap.put(passPrices[2], passPrices[2] + "Yearly");
		model.addAttribute("passPrices", passMap);
		model.addAttribute("pass", new Pass());
		return "getPass";
	}
	
	@PostMapping("/getPass") 
	public String getFinalPass(@Validated Pass pass, BindingResult result, RedirectAttributes reAttribute) {
		double plan = Double.parseDouble(pass.getPlan());
		String currency = pass.getCurrency();
		if("YEN".equals(currency)) {
			plan = plan*1.49;
		} else if ("USD".equals(currency)) {
			plan = plan * 0.014;
		}
		reAttribute.addAttribute("passPrice", plan);
		return  "redirect:/pass";
	}
	
	@GetMapping("/pass") 
	public String pass(@RequestParam("passPrice") double passPrice, Model model) {
		model.addAttribute("passPrice", passPrice);
		return "pass";
	}
	
	

	@GetMapping("/login") 
	public String login(Model model) {
		model.addAttribute("loginEmployee", new LoginEmployee());
		return "login";
	}
	
	@PostMapping("/login")
	public String getLoggedIn(@Validated LoginEmployee loginEmployee, BindingResult result, RedirectAttributes attributes, HttpServletRequest request){
		if(result.hasErrors()) {
			return "login";
		} else {
			for(Employee emp : employeeList) {
				if(emp.getEmailId().equals(loginEmployee.getEmailId())) {
					if (emp.getPassword().equals(loginEmployee.getPassword())) {
						attributes.addAttribute("email", loginEmployee.getEmailId());
						HttpSession session = request.getSession();
						session.setAttribute("loggedIn", true);
						return "redirect:/home";
					} else {
						attributes.addFlashAttribute("errorMsg", "Enter a valid password");
						return "redirect:/login";
					}
				} 
			} 
			attributes.addFlashAttribute("errorMsg", "Enter a valid details");
			return "redirect:/login";
		}
	}
	
	@GetMapping("/home") 
	public String getHome(@RequestParam("email") String email, Model model) {
		for(Employee emp : employeeList) {
			if(emp.getEmailId().equals(email)) {
				model.addAttribute("employee", emp);
			}
		}
		return "home";
	}
	
	@GetMapping("/update")
	public String update(@PathVariable("employee") Employee employee, Model model) {
		model.addAttribute("employee", employee);
		return "update";
	}
	
	/*@PostMapping("/update")
	public String updateEmployee(@Validated Employee employee, BindingResult result) {
		if(result.hasErrors()) {
			return "update";
		} else {
			
		}
	}
	
	
	@GetMapping("/friends")
	public String friends() {
		return "friends";
	}
	*/
	
	@GetMapping("/logout")
	public String logOut(HttpSession session) {
		session.invalidate();
		return "redirect:/login";
	}
//	@GetMapping("/register")
//	public String register(Model model) {
//		model.addAttribute("register", new Employee());
//		return "register";
//	}
//	
//	@PostMapping("/register") 
//	public String registerEmployee(@Validated Employee employee, BindingResult result, Model model) {
//		if (result.hasErrors()) {
//			return "register";
//			
//		} else {
//			model.addAttribute("vehicle", new Vehicle());
//			return "vehicleForm";
//		}
//	}
//	@PostMapping("/registerEmployee")
//	public String registerEmployee(@Validated Employee employee, BindingResult result, Model model) {
//		if(result.hasErrors()) {
//			model.addAttribute("register", new Employee());
//			return "register";
//		} else {
//			return "vehicleForm";
//		}
//	}
}
