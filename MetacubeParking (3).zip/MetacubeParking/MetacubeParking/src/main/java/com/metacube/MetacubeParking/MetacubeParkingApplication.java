package com.metacube.MetacubeParking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class MetacubeParkingApplication {

	public static void main(String[] args) {
		SpringApplication.run(MetacubeParkingApplication.class, args);
	}

}
