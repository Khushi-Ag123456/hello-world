package com.metacube.StudentHibernate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentHibernateApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentHibernateApplication.class, args);
	}

}
