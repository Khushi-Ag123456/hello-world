package com.metacube.MetacubeParkingJdbc.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.metacube.MetacubeParkingJdbc.mapper.EmployeeMapper;
import com.metacube.MetacubeParkingJdbc.mapper.PassMapper;
import com.metacube.MetacubeParkingJdbc.model.Employee;
import com.metacube.MetacubeParkingJdbc.model.PassDetails;
import com.metacube.MetacubeParkingJdbc.model.Vehicle;

@Repository
public class EmployeeDaoImp implements EmployeeDao {

	

	private JdbcTemplate jdbcTemplate;

	private final String SQL_INSERT_EMPLOYEE = "INSERT INTO employeeDetails(fullName, gender, emailId, password, contactNo, organization) values(?,?,?,?,?,?)";
	private final String SQL_GET_EMPLOYEEID = "SELECT LAST_INSERT_ID() FROM employeeDetails";
	private final String SQL_INSERT_VEHICLE = "INSERT INTO vehicle(empId, name, type, vehicle_number, identification) VALUES(?,?,?,?,?)";
	private final String SQL_AUTH = "SELECT password FROM employeeDetails WHERE emailId = ?";
	private final String SQL_UPDATE_EMPLOYEE = "UPDATE employeeDetails SET fullName = ?, gender = ?, password = ?, contactNo = ?, organization = ? where emailId = ?";
	private final String SQL_GET_FRIENDS = "SELECT * FROM employeeDetails WHERE organization = (SELECT organization FROM employeeDetails WHERE emailId = ?) and emailId <> ?";
	private final String SQL_GET_PASS = "SELECT daily, monthly, yearly FROM pass WHERE vehicle_type = ?";
	private final String SQL_GET_EMPBYMAIL = "SELECT * FROM employeeDetails WHERE emailId = ?";
	private final String SQL_INSERT_IMAGE = "Insert into image(imageUrl, emailId) values(?, ?)";

	
	@Autowired
	public EmployeeDaoImp(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	@Override
	public boolean addEmployee(Employee emp) {
		return jdbcTemplate.update(
				SQL_INSERT_EMPLOYEE,
				 emp.getFullName(), emp.getGender(),
						emp.getEmailId(), emp.getPassword(),
						emp.getContactNumber(), emp.getOrganization() ) > 0;

	}

	@Override
	public int getEmployeeId() {
		System.out.println(jdbcTemplate.queryForObject(SQL_GET_EMPLOYEEID, Integer.class));
		return jdbcTemplate.queryForObject(SQL_GET_EMPLOYEEID, Integer.class);
	}

	@Override
	public String auth(String email) {
		return jdbcTemplate.queryForObject(SQL_AUTH, new Object[]{email}, String.class);
	}

	@Override
	public boolean addVehicle(Vehicle v) {
		return jdbcTemplate.update(
				SQL_INSERT_VEHICLE,
				 v.getEmployeeId(), v.getVehicleName(),
						v.getVehicleType(), v.getVehicleNo(),
						v.getIdentification() ) > 0;
	}

	@Override
	public PassDetails getPassPrice(String type) {
		return jdbcTemplate.queryForObject(SQL_GET_PASS, new Object[]{type}, new PassMapper());
	}

	@Override
	public Employee getEmployeeByEmail(String email) {
		return jdbcTemplate.queryForObject(SQL_GET_EMPBYMAIL,
				new Object[] { email }, new EmployeeMapper());
	}

	@Override
	public boolean updateEmployee(Employee emp) {
		return jdbcTemplate.update(SQL_UPDATE_EMPLOYEE, emp.getFullName(),
				emp.getGender(), emp.getPassword(), emp.getContactNumber(),
				emp.getOrganization(), emp.getEmailId()) > 0;
	}

	@Override
	public List<Employee> getFriends(String email) {
		return jdbcTemplate.query(SQL_GET_FRIENDS, new Object[] {email, email}, new EmployeeMapper());
	}

	@Override
	public boolean addImage(String image, String emailId) {
		return jdbcTemplate.update(SQL_INSERT_IMAGE, image, emailId) > 0;
	}

}
