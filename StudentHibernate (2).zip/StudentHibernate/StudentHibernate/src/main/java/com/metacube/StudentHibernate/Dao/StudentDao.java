package com.metacube.StudentHibernate.Dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.orm.hibernate3.HibernateTemplate;

import com.metacube.StudentHibernate.model.Student;

public class StudentDao {

	HibernateTemplate template;
	
	public void setTemplate(HibernateTemplate template) {
		this.template = template;
	}
	
	public void saveStudent(Student stu) {
		template.save(stu);
	}
	
	public List<Student> getStudents() {
		List<Student> studentList = new ArrayList<Student>();
		studentList = template.loadAll(Student.class);
		return studentList;
				
	}
}
