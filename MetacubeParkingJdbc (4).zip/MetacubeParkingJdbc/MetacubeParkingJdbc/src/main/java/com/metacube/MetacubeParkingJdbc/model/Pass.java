package com.metacube.MetacubeParkingJdbc.model;

/**
 * pojo class for pass
 * @author Khushi
 *
 */
public class Pass {

	private String plan;
	private String currency;
	
	public String getPlan() {
		return plan;
	}
	public void setPlan(String plan) {
		this.plan = plan;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	
	
}
