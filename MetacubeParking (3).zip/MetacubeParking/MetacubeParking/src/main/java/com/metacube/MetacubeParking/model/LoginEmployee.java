package com.metacube.MetacubeParking.model;

import javax.validation.constraints.NotBlank;

public class LoginEmployee {

	@NotBlank(message = "{blankMsg}")
	private String emailId;
	
	@NotBlank(message = "{blankMsg}")
	private String password;

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
