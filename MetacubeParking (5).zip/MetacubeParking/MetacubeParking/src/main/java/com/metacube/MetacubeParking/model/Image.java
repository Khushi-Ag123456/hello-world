package com.metacube.MetacubeParking.model;

import org.springframework.web.multipart.MultipartFile;

public class Image {

	private String image;
	private String email;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	
}
