package com.metacube.MetacubeParkingJdbc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MetacubeParkingJdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(MetacubeParkingJdbcApplication.class, args);
	}

}
