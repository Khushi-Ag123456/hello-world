package com.metacube.MetacubeParking.model;

import org.springframework.web.multipart.MultipartFile;

public class Image {

	private MultipartFile image;

	public MultipartFile getImage() {
		return image;
	}

	public void setImage(MultipartFile image) {
		this.image = image;
	}

	
}
